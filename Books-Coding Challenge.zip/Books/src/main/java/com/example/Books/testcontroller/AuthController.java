package com.example.Books.testcontroller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class AuthController {
	
	@GetMapping("/public")
	public String publicEndPoint() {
		return "It is public end point";
	}
	
	@GetMapping("/user")
	public String userEndPoint() {
		return "It is user end point";
	}
	
	@GetMapping("/admin")
	public String adminEndPoint() {
		return "It is admin end point";
	}
	
}
