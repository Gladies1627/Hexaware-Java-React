package com.example.Books.controller;



import com.example.Books.entity.Book;
import com.example.Books.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService service;

    @GetMapping
    public List<Book> getAll() {
        return service.getAllBooks();
    }

    @GetMapping("/{isbn}")
    public Book getByIsbn(@PathVariable String isbn) {
        return service.getBookByIsbn(isbn);
    }

    @PostMapping
    public Book create(@RequestBody Book book) {
        return service.addBook(book);
    }

    @PutMapping("/{isbn}")
    public Book update(@PathVariable String isbn, @RequestBody Book book) {
        return service.updateBook(isbn, book);
    }

    @DeleteMapping("/{isbn}")
    public String delete(@PathVariable String isbn) {
        return service.deleteBook(isbn);
    }
}

