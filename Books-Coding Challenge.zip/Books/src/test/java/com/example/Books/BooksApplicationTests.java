package com.example.Books;

import com.example.Books.entity.Book;
import com.example.Books.repository.BookRepository;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class BooksApplicationTests {

    @Autowired
    private BookRepository bookRepository;

    private Book testBook;

    @BeforeEach
    void setup() {
        testBook = new Book();
        testBook.setIsbn("BK1001");
        testBook.setTitle("Learning Java");
        testBook.setAuthor("Gladies Mary");
        testBook.setPublicationYear(2024);

        bookRepository.save(testBook);
    }

    @Test
    void testAddBook() {
        Optional<Book> book = bookRepository.findById("BK1001");
        assertTrue(book.isPresent());
        assertEquals("Learning Java", book.get().getTitle());
    }

    @Test
    void testFindById() {
        Book found = bookRepository.findById("BK1001").orElse(null);
        assertNotNull(found);
        assertEquals("Gladies Mary", found.getAuthor());
    }

    @Test
    void testUpdateBook() {
        Book updatedBook = bookRepository.findById("BK1001").orElse(null);
        assertNotNull(updatedBook);
        updatedBook.setTitle("Mastering Java");
        bookRepository.save(updatedBook);

        Book found = bookRepository.findById("BK1001").orElse(null);
        assertEquals("Mastering Java", found.getTitle());
    }

    @Test
    void testDeleteBook() {
        bookRepository.deleteById("BK1001");
        assertFalse(bookRepository.findById("BK1001").isPresent());
    }

    @Test
    void testGetAllBooks() {
        var books = bookRepository.findAll();
        assertFalse(books.isEmpty());
    }

    @Test
    void testAllArgsConstructor() {
        Book book = new Book("BK1002", "Java for Beginners", "Mary John", 2025);

        assertEquals("BK1002", book.getIsbn());
        assertEquals("Java for Beginners", book.getTitle());
        assertEquals("Mary John", book.getAuthor());
        assertEquals(2025, book.getPublicationYear());
    }

    @Test
    void testGettersAndSetters() {
        Book book = new Book();
        book.setIsbn("BK1003");
        book.setTitle("Spring Boot Essentials");
        book.setAuthor("David Raj");
        book.setPublicationYear(2023);

        assertEquals("BK1003", book.getIsbn());
        assertEquals("Spring Boot Essentials", book.getTitle());
        assertEquals("David Raj", book.getAuthor());
        assertEquals(2023, book.getPublicationYear());
    }

    @AfterEach
    void cleanUp() {
        bookRepository.deleteAll();
    }
}
