package com.fastx.busbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusbookingApplication {

    public static void main(String[] args) {
        SpringApplication.run(BusbookingApplication.class, args);
    }
}
