package entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "bus_routes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusRoute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "operator_id")
    private User operator; // Role = OPERATOR

    private String busName;

    @Column(unique = true)
    private String busNumber;

    @Enumerated(EnumType.STRING)
    private BusType busType;

    private String origin;

    private String destination;

    private LocalDateTime departureTime;

    private LocalDateTime arrivalTime;

    private Double farePerSeat;

    private Integer totalSeats;

    private String amenities; // Comma-separated (e.g., "TV,Water Bottle")

    @OneToMany(mappedBy = "route", cascade = CascadeType.ALL)
    private List<Seat> seats;

    public enum BusType {
        SLEEPER_AC, SLEEPER_NON_AC, SEATER_AC, SEATER_NON_AC
    }
}
