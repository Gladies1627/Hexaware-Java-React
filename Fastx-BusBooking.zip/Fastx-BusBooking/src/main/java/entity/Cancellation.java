package entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "cancellations")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cancellation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private LocalDateTime cancelledOn = LocalDateTime.now();

    private Double refundAmount;

    @OneToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;
}
