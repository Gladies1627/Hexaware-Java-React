package com.fastx.busbooking;

import com.fastx.busbooking.entity.User;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class UserEntityTest {

    @Test
    void testAllArgsConstructor() {
        User user = new User(
                1,
                "Alice",
                "alice@example.com",
                "secret123",
                "9876543210",
                "Female",
                "Chennai",
                User.Role.PASSENGER
        );

        assertEquals(1, user.getId());
        assertEquals("Alice", user.getName());
        assertEquals("alice@example.com", user.getEmail());
        assertEquals("secret123", user.getPassword());
        assertEquals("9876543210", user.getContactNumber());
        assertEquals("Female", user.getGender());
        assertEquals("Chennai", user.getAddress());
        assertEquals(User.Role.PASSENGER, user.getRole());
    }

    @Test
    void testGettersAndSetters() {
        User user = new User();

        user.setId(2);
        user.setName("Bob");
        user.setEmail("bob@example.com");
        user.setPassword("pass456");
        user.setContactNumber("1234567890");
        user.setGender("Male");
        user.setAddress("Hosur");
        user.setRole(User.Role.OPERATOR);

        assertEquals(2, user.getId());
        assertEquals("Bob", user.getName());
        assertEquals("bob@example.com", user.getEmail());
        assertEquals("pass456", user.getPassword());
        assertEquals("1234567890", user.getContactNumber());
        assertEquals("Male", user.getGender());
        assertEquals("Hosur", user.getAddress());
        assertEquals(User.Role.OPERATOR, user.getRole());
    }
}
