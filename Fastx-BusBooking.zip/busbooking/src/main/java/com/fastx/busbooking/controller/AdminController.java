package com.fastx.busbooking.controller;

import com.fastx.busbooking.entity.BusRoute;
import com.fastx.busbooking.repository.BookingRepository;
import com.fastx.busbooking.repository.BusRouteRepository;
import com.fastx.busbooking.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BusRouteRepository busRouteRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @GetMapping
    public String dashboard(Model model, HttpSession session) {
        model.addAttribute("users", userRepository.findAll());
        model.addAttribute("busRoutes", busRouteRepository.findAll());
        return "admin";
    }

    @GetMapping("/admin/editRoute/{id}")
    public String showEditRouteForm(@PathVariable("id") Integer id, Model model) {
        BusRoute route = busRouteRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Route ID"));
        model.addAttribute("route", route);
        return "edit-route";
    }

    @PostMapping("/admin/updateRoute")
    public String updateRoute(@ModelAttribute("route") BusRoute updatedRoute) {
        busRouteRepository.save(updatedRoute);
        return "redirect:/admin";
    }

 
    @PostMapping("/deleteUser/{id}")
    @Transactional
    public String deleteUser(@PathVariable int id) {
        bookingRepository.deleteByPassenger_Id(id); 
        userRepository.deleteById(id);
        return "redirect:/admin";
    }


    @PostMapping("/deleteRoute/{id}")
    public String deleteRoute(@PathVariable int id) {
        busRouteRepository.deleteById(id);
        return "redirect:/admin";
    }
}
