package com.fastx.busbooking.apiController;

import com.fastx.busbooking.entity.Seat;
import com.fastx.busbooking.repository.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seats")
@CrossOrigin("*")
public class SeatApiController {

    @Autowired
    private SeatRepository seatRepo;

    @GetMapping("/bus-route/{routeId}")
    public List<Seat> getSeatsForRoute(@PathVariable Integer routeId) {
        return seatRepo.findByRoute_Id(routeId);
    }

    @PostMapping
    public ResponseEntity<Seat> addSeat(@RequestBody Seat seat) {
        return ResponseEntity.ok(seatRepo.save(seat));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Seat> updateSeat(@PathVariable Integer id, @RequestBody Seat seat) {
        seat.setId(id);
        return ResponseEntity.ok(seatRepo.save(seat));
    }
}
