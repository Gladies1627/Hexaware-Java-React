package com.fastx.busbooking.controller;

import com.fastx.busbooking.entity.BusRoute;
import com.fastx.busbooking.repository.BusRouteRepository;
import com.fastx.busbooking.service.BusRouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/operator")
public class OperatorController {

    @Autowired
    private BusRouteService busRouteService;
    
    @Autowired
    private BusRouteRepository busRouteRepository;
   

    @GetMapping
    public String showOperatorDashboard(Model model) {
        model.addAttribute("routes", busRouteService.getAllRoutes());
        return "operator"; 
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("route", new BusRoute());
        return "route_form"; 
    }

    @GetMapping("/edit/{id}")
    public String editRoute(@PathVariable Integer id, Model model) {
        model.addAttribute("route", busRouteService.getRouteById(id));
        return "route_form";
    }
    @PostMapping("/save")
    public String saveRoute(@ModelAttribute BusRoute route, RedirectAttributes redirectAttributes) {
        busRouteRepository.save(route);
        redirectAttributes.addFlashAttribute("message", "Route saved successfully!");
        return "redirect:/operator";
    }

    @GetMapping("/delete/{id}")
    public String deleteRoute(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        busRouteRepository.deleteById(id);
        redirectAttributes.addFlashAttribute("message", "Route deleted successfully!");
        return "redirect:/operator";
    }

}
