package com.fastx.busbooking.apiController;

import com.fastx.busbooking.entity.Cancellation;
import com.fastx.busbooking.repository.CancellationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/cancellations")
@CrossOrigin("*")
public class CancellationApiController {

    @Autowired
    private CancellationRepository cancelRepo;

    @PostMapping
    public ResponseEntity<Cancellation> cancelTicket(@RequestBody Cancellation cancel) {
        cancel.setCancelledAt(LocalDateTime.now());
        return ResponseEntity.ok(cancelRepo.save(cancel));
    }

    @GetMapping
    public List<Cancellation> getAllCancellations() {
        return cancelRepo.findAll();
    }

    @GetMapping("/user/{userId}")
    public List<Cancellation> getUserCancellations(@PathVariable Integer userId) {
        return cancelRepo.findByUserId(userId);
    }
}
