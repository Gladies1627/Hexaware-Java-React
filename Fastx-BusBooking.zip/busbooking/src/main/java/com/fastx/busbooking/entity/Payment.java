package com.fastx.busbooking.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "payment")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private LocalDateTime paymentDate = LocalDateTime.now();

    private Double amountPaid;

    private String paymentMode;

    @Enumerated(EnumType.STRING)
    private Status paymentStatus = Status.SUCCESS;

    @OneToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;

    public enum Status {
        SUCCESS, FAILED, REFUNDED
    }
}
