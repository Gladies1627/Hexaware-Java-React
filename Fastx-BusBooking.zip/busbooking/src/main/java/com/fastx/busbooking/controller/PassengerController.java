package com.fastx.busbooking.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fastx.busbooking.entity.BusRoute;
import com.fastx.busbooking.repository.BusRouteRepository;



@Controller
@RequestMapping("/passenger")
public class PassengerController {

    @Autowired
    private BusRouteRepository busRouteRepository;

    @PostMapping("/search")
    public String searchRoutes(@RequestParam String origin,
                               @RequestParam String destination,
                               Model model) {
        List<BusRoute> routes = busRouteRepository.findByOriginAndDestination(origin, destination);
        model.addAttribute("routes", routes);
        return "bus-results"; 
    }
}


