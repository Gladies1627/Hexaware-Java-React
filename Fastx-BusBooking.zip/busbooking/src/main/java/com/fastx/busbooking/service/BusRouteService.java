package com.fastx.busbooking.service;

import com.fastx.busbooking.entity.BusRoute;
import com.fastx.busbooking.repository.BusRouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusRouteService {

    @Autowired
    private BusRouteRepository busRouteRepository;

    public List<BusRoute> getAllRoutes() {
        return busRouteRepository.findAll();
    }

    public BusRoute saveRoute(BusRoute route) {
        return busRouteRepository.save(route);
    }

    public void deleteRoute(Integer id) {
        busRouteRepository.deleteById(id);
    }

    public BusRoute getRouteById(Integer id) {
        return busRouteRepository.findById(id).orElse(null);
    }
}
