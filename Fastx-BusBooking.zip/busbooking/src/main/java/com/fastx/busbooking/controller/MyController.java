package com.fastx.busbooking.controller;

import com.fastx.busbooking.entity.User;
import com.fastx.busbooking.service.userService;

import jakarta.servlet.http.HttpSession;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class MyController {

    @Autowired
    private userService userService;

    @GetMapping("/")
    public String showHomePage() {
        return "home";
    }

    @PostMapping("/register")
    public String registerUser(User user, Model model) {
        userService.saveUser(user);
        model.addAttribute("registeredUser", user);
        return "home";
    }

    @PostMapping("/login")
    public String login(@RequestParam String name,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {

        Optional<User> userOptional = userService.findByCredentials(name, password);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            session.setAttribute("loggedInUser", user);

            switch (user.getRole()) {
            case PASSENGER:
                return "redirect:/passenger";
            case OPERATOR:
                return "redirect:/operator";
            case ADMIN:
                return "redirect:/admin"; 
            default:
                model.addAttribute("error", "Unknown role");
                return "home";
        }


        } else {
            model.addAttribute("error", "Invalid credentials");
            return "home";
        }
    }
    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); 
        return "redirect:/"; 
    }
    
    


   
    
    

    
}
