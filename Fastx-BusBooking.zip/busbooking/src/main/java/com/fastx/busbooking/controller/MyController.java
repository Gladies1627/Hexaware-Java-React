package com.fastx.busbooking.controller;

import com.fastx.busbooking.entity.User;
import com.fastx.busbooking.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
public class MyController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/")
    public String showHomePage() {
        return "home";
    }

    @PostMapping("/register")
    public String registerUser(User user, Model model) {
        userRepository.save(user);
        model.addAttribute("registeredUser", user);
        return "home";
        }
    

    @PostMapping("/login")
    public String login(@RequestParam String name,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {

        Optional<User> userOptional = userRepository.findAll()
                .stream()
                .filter(user -> user.getName().equals(name) && user.getPassword().equals(password))
                .findFirst();

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            session.setAttribute("loggedInUser", user);

            if (user.getRole().equals(User.Role.PASSENGER)) {
                return "redirect:/passenger";
            } else if (user.getRole().equals(User.Role.OPERATOR)) {
                return "loginsuccess";
            } else if (user.getRole().equals(User.Role.ADMIN)) {
                return "loginsuccess";
            } else {
                model.addAttribute("error", "Unknown role");
                return "home";
            }

        } else {
            model.addAttribute("error", "Invalid credentials");
            return "home";
        }
    }
    @GetMapping("/passenger")
    public String passengerPage() {
        return "passenger";
    }





}
