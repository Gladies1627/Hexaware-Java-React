package com.fastx.busbooking.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "bookings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private LocalDateTime bookingDate = LocalDateTime.now();

    private LocalDate travelDate;

    @Enumerated(EnumType.STRING)
    private Status status = Status.CONFIRMED;

    private Double totalAmount;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User passenger;

    @ManyToOne
    @JoinColumn(name = "route_id")
    private BusRoute route;

    @OneToMany(mappedBy = "booking", cascade = CascadeType.MERGE)
    private List<Seat> seats;


    public enum Status {
        CONFIRMED, CANCELLED
    }
}
