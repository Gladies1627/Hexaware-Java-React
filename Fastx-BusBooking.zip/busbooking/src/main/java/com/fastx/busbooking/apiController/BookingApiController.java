package com.fastx.busbooking.apiController;

import com.fastx.busbooking.entity.Booking;
import com.fastx.busbooking.entity.Seat;
import com.fastx.busbooking.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin("*")
public class BookingApiController {

    @Autowired
    private BookingRepository bookingRepo;

    @PostMapping
    public ResponseEntity<Booking> createBooking(@RequestBody Booking booking) {
        booking.setBookingDate(LocalDateTime.now());

        
        if (booking.getSeats() != null) {
            for (Seat seat : booking.getSeats()) {
                seat.setBooking(booking);
                seat.setBooked(true); 
            }
        }
        Booking savedBooking = bookingRepo.saveAndFlush(booking);
        return ResponseEntity.ok(savedBooking);
    }



    @GetMapping
    public List<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }

    @GetMapping("/user/{userId}")
    public List<Booking> getUserBookings(@PathVariable Integer userId) {
        return bookingRepo.findByPassenger_Id(userId);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelBooking(@PathVariable Integer id) {
        bookingRepo.deleteById(id);
        return ResponseEntity.ok("Booking cancelled");
    }
}
