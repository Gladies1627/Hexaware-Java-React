package com.fastx.busbooking.repository;

import com.fastx.busbooking.entity.Seat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SeatRepository extends JpaRepository<Seat, Integer> {

    // FIXED: use route.id since Seat has a 'route' object
    List<Seat> findByRoute_Id(Integer routeId); 
}
