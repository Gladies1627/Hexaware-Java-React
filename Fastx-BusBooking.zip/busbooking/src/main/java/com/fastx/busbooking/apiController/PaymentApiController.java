package com.fastx.busbooking.apiController;

import com.fastx.busbooking.entity.Payment;
import com.fastx.busbooking.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin("*")
public class PaymentApiController {

    @Autowired
    private PaymentRepository paymentRepo;

  
    @PostMapping
    public ResponseEntity<Payment> createPayment(@RequestBody Payment payment) {
        payment.setPaymentDate(LocalDateTime.now());
        return ResponseEntity.ok(paymentRepo.save(payment));
    }


    @GetMapping
    public List<Payment> getAllPayments() {
        return paymentRepo.findAll();
    }

 
    @GetMapping("/{id}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Integer id) {
        Optional<Payment> payment = paymentRepo.findById(id);
        return payment.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePayment(@PathVariable Integer id) {
        paymentRepo.deleteById(id);
        return ResponseEntity.ok("Payment deleted");
    }
}
