package com.fastx.busbooking.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;
    private String email;
    private String password;
    private String contactNumber;
    private String gender;
    private String address;

    @Enumerated(EnumType.STRING)
    private Role role;

    public enum Role {
        PASSENGER, OPERATOR, ADMIN
    }
}
