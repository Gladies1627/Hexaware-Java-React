package com.fastx.busbooking.repository;

import com.fastx.busbooking.entity.Cancellation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CancellationRepository extends JpaRepository<Cancellation, Integer> {
    List<Cancellation> findByUserId(Integer userId);
}
