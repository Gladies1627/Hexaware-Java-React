package com.fastx.busbooking.apiController;

import com.fastx.busbooking.entity.BusRoute;
import com.fastx.busbooking.repository.BusRouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/routes")
public class BusRouteApiController {

    @Autowired
    private BusRouteRepository busRouteRepository;

    @GetMapping
    public List<BusRoute> getAllRoutes() {
        return busRouteRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<BusRoute> getRouteById(@PathVariable Integer id) {
        return busRouteRepository.findById(id);
    }

    @PostMapping
    public BusRoute createRoute(@RequestBody BusRoute route) {
        return busRouteRepository.save(route);
    }

    @PutMapping("/{id}")
    public BusRoute updateRoute(@PathVariable Integer id, @RequestBody BusRoute route) {
        route.setId(id);
        return busRouteRepository.save(route);
    }

    @DeleteMapping("/{id}")
    public void deleteRoute(@PathVariable Integer id) {
        busRouteRepository.deleteById(id);
    }
}
