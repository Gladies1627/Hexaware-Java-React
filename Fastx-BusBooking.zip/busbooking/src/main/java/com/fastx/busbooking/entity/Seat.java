package com.fastx.busbooking.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "seats")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Seat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String seatNumber;

    private boolean isBooked = false;

    @ManyToOne
    @JoinColumn(name = "route_id")
    private BusRoute route;

    @ManyToOne
    @JoinColumn(name = "booking_id", nullable = true)
    private Booking booking; // can be null until booked
}
