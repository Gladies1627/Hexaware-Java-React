package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Books;
import com.example.demo.repo.BooksRepository;

@Service
public class BooksService {
	@Autowired
	private BooksRepository booksRepository;
	
	public List<Books> showBooks(){
		return booksRepository.findAll();
	}
	public Books getBookByIsbn(String isbn) {
	    return booksRepository.findById(isbn)
	            .orElseThrow(() -> new ResourceNotFoundException("Book not found with ISBN: " + isbn));
	}


    public String addBook(Books books) {
       booksRepository.save(books);
       return "Book added Successfully";
    }

    public String updateBook(Books books) {
        booksRepository.save(books);
        return "Book updated Successfully";
    }

    public String deleteBook(String isbn) {
        Books book = booksRepository.findById(isbn)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot delete. Book not found with ISBN: " + isbn));
        
        booksRepository.delete(book);
        return "Book deleted successfully";
    }

}
