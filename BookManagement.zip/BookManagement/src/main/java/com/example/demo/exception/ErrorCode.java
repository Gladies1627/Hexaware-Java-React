package com.example.demo.exception;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter@Setter

@NoArgsConstructor@ToString
public class ErrorCode {
	  public ErrorCode(int value, Date date, String message2, String description2) {
		// TODO Auto-generated constructor stub
	}
	  private int statusCode;
	  private Date timestamp;
	  private String message;
	  private String description;
}
