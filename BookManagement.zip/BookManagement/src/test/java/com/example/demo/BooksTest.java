package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import com.example.demo.model.Books;
import org.junit.jupiter.api.Test;

public class BooksTest {

    @Test
    public void testToString() {
        Books book = new Books("9780000000011", "Pride and Prejudice", "Jane Austen", 1813, "Fiction", 150.00);
        String expected = "Books [isbn=9780000000011, title=Pride and Prejudice, author=Jane Austen, publicationYear=1813, genre=Fiction, price=150.0]";
        assertEquals(expected, book.toString());
    }

    @Test
    public void testGettersAndSetters() {
        Books book = new Books();
        book.setIsbn("9780000000059");
        book.setTitle("Clean Code");
        book.setAuthor("Robert C. Martin");
        book.setPublicationYear(2008);
        book.setGenre("Technology");
        book.setPrice(300.00);

        assertEquals("9780000000059", book.getIsbn());
        assertEquals("Clean Code", book.getTitle());
        assertEquals("Robert C. Martin", book.getAuthor());
        assertEquals(2008, book.getPublicationYear());
        assertEquals("Technology", book.getGenre());
        assertEquals(300.00, book.getPrice(), 0.001);
    }

    @Test
    public void testConstructor() {
        Books book = new Books("9780000000042", "The Diary of a Young Girl", "Anne Frank", 1947, "Biography", 250.00);
        assertNotNull(book);
        assertEquals("9780000000042", book.getIsbn());
        assertEquals("The Diary of a Young Girl", book.getTitle());
        assertEquals("Anne Frank", book.getAuthor());
        assertEquals(1947, book.getPublicationYear());
        assertEquals("Biography", book.getGenre());
        assertEquals(250.00, book.getPrice(), 0.001);
    }
}
