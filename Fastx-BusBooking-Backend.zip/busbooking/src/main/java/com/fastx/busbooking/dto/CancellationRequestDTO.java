package com.fastx.busbooking.dto;



import lombok.Data;

@Data
public class CancellationRequestDTO {
    public String reason;
}
